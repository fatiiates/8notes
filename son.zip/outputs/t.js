const Database = require('../lib/_db');
const fs = require('fs/promises');
(async function name(params) {
    try {
        const client = await Database.connect();
    
        await Database.createScrapingsCollection();
    
        const db = await Database.selectDatabase();
        var filename = '/all/pieces_dump_1620246750235_b7e23dfa-bb59-45e8-8eac-7500da02c347.json';
        const filenameSplit = filename.split('_');
        
        await fs.readFile(__dirname + filename, { encoding:'utf8',flag: 'r' })
            .then(async data => {
                await db.collection("scrapings").insertOne({
                    [filenameSplit[2]]: JSON.parse(data)
                });
            })
            .catch(err => { throw err }); 
            
    } catch (error) {
        console.log(error);
    }
    finally {
        await Database.destroy();
    }
})()